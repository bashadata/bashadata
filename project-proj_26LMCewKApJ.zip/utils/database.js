let itemsStore = [];

async function dbAddItem(item) {
  try {
    const newItem = { ...item, id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}` };
    itemsStore.push(newItem);
    return newItem;
  } catch (error) {
    console.error('Error adding item:', error);
    throw error;
  }
}

async function dbGetAllItems() {
  try {
    return itemsStore;
  } catch (error) {
    console.error('Error getting items:', error);
    return [];
  }
}

async function dbDeleteItem(id) {
  try {
    itemsStore = itemsStore.filter(item => item.id !== id);
    return true;
  } catch (error) {
    console.error('Error deleting item:', error);
    throw error;
  }
}

async function dbUpdateItem(id, updates) {
  try {
    const index = itemsStore.findIndex(item => item.id === id);
    if (index !== -1) {
      itemsStore[index] = { ...itemsStore[index], ...updates };
      return itemsStore[index];
    }
    return null;
  } catch (error) {
    console.error('Error updating item:', error);
    throw error;
  }
}