// Initialize default admin account
function initializeDefaultAdmin() {
  const users = JSON.parse(localStorage.getItem('pashaUsers') || '[]');
  if (users.length === 0) {
    users.push({
      username: 'admin',
      password: 'admin',
      name: 'المشرف',
      isAdmin: true
    });
    localStorage.setItem('pashaUsers', JSON.stringify(users));
  }
}

// Call initialization
initializeDefaultAdmin();

async function authLogin(username, password) {
  const users = JSON.parse(localStorage.getItem('pashaUsers') || '[]');
  const user = users.find(u => u.username === username && u.password === password);
  
  if (user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
    return { success: true, isAdmin: user.isAdmin };
  }
  return { success: false };
}

async function authRegisterMember(data) {
  const members = JSON.parse(localStorage.getItem('pendingMembers') || '[]');
  members.push({ ...data, id: Date.now().toString(), pending: true });
  localStorage.setItem('pendingMembers', JSON.stringify(members));
}

function authGetCurrentUser() {
  return JSON.parse(localStorage.getItem('currentUser') || 'null');
}

function authLogout() {
  localStorage.removeItem('currentUser');
  window.location.href = 'login.html';
}

function authIsAdmin() {
  const user = authGetCurrentUser();
  return user && user.isAdmin;
}