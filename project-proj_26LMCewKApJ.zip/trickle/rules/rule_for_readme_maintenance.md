When updating the Pasha Data project
- Check if any major features or functionality have been added or changed
- Update the README.md file in trickle/notes to reflect these changes
- Keep the documentation concise and in Arabic
- Update the "آخر تحديث" (Last Update) date when making changes