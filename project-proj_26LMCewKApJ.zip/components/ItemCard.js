function ItemCard({ item, onDelete, isAdmin }) {
  try {
    return (
      <div className="card hover:border-[var(--primary-color)] transition-all" data-name="item-card" data-file="components/ItemCard.js">
        {item.image && (
          <img src={item.image} alt={item.name} className="w-full h-48 object-cover rounded-lg mb-4" />
        )}
        
        <h3 className="text-xl font-bold mb-2">{item.name}</h3>
        
        <div className="space-y-2 text-sm text-gray-400">
          <div className="flex items-center gap-2">
            <div className="icon-hard-drive text-[var(--accent-color)]"></div>
            <span>الحجم: {item.size} GB</span>
          </div>
          
          {item.season && (
            <div className="flex items-center gap-2">
              <div className="icon-calendar text-[var(--accent-color)]"></div>
              <span>الموسم: {item.season}</span>
            </div>
          )}
          
          {item.episodes && (
            <div className="flex items-center gap-2">
              <div className="icon-list text-[var(--accent-color)]"></div>
              <span>الحلقات: {item.episodes}</span>
            </div>
          )}
          
          {item.notes && (
            <div className="flex items-center gap-2 text-xs">
              <div className="icon-file-text text-[var(--accent-color)]"></div>
              <span>{item.notes}</span>
            </div>
          )}
        </div>

        {isAdmin && (
          <button
            onClick={() => onDelete(item.id)}
            className="mt-4 w-full bg-red-600 hover:bg-red-700 text-white py-2 rounded-lg transition-all"
          >
            حذف
          </button>
        )}
      </div>
    );
  } catch (error) {
    console.error('ItemCard component error:', error);
    return null;
  }
}