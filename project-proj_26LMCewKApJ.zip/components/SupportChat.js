function SupportChat() {
  try {
    const [isOpen, setIsOpen] = React.useState(false);
    const [messages, setMessages] = React.useState([]);
    const [input, setInput] = React.useState('');

    const chatSettings = JSON.parse(localStorage.getItem('chatSettings') || '{"autoReply":"مرحباً! كيف يمكنني مساعدتك؟","autoReplyColor":"#8b5cf6","emojis":["😊","👍","🎉","💯"]}');

    const handleSend = () => {
      if (!input.trim()) return;
      setMessages([...messages, { text: input, from: 'user' }]);
      setTimeout(() => {
        setMessages(prev => [...prev, { text: chatSettings.autoReply, from: 'support', color: chatSettings.autoReplyColor }]);
      }, 500);
      setInput('');
    };
    
    const clearMessages = () => {
      setMessages([]);
    };
    
    const handleClose = () => {
      setMessages([]);
      setIsOpen(false);
    };

    return (
      <>
        <div className={`fixed bottom-6 left-6 z-50 ${isOpen ? 'hidden' : 'block'}`}>
          <button
            onClick={() => setIsOpen(true)}
            className="bg-[var(--primary-color)] hover:bg-purple-600 text-white p-4 rounded-full shadow-lg flex items-center gap-2"
          >
            <div className="icon-headphones text-2xl"></div>
          </button>
        </div>

        {isOpen && (
          <div className="fixed bottom-6 left-6 z-50 w-96 bg-[var(--bg-card)] border border-[var(--border-color)] rounded-lg shadow-xl">
            <div className="bg-[var(--primary-color)] p-4 rounded-t-lg flex justify-between items-center">
              <h3 className="font-bold text-white">الدعم الفني</h3>
              <div className="flex gap-2">
                <button onClick={clearMessages} className="text-white hover:text-gray-200">
                  <div className="icon-trash-2 text-xl"></div>
                </button>
                <button onClick={handleClose} className="text-white hover:text-gray-200">
                  <div className="icon-x text-xl"></div>
                </button>
              </div>
            </div>
            
            <div className="h-96 overflow-y-auto p-4 space-y-3">
              {messages.map((msg, idx) => (
                <div key={idx} className={`flex ${msg.from === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-xs p-3 rounded-lg ${msg.from === 'user' ? 'bg-[var(--primary-color)] text-white' : ''}`} style={msg.from === 'support' && msg.color ? {backgroundColor: msg.color, color: 'white'} : msg.from === 'support' ? {backgroundColor: '#374151'} : {}}>
                    {msg.text}
                  </div>
                </div>
              ))}
            </div>
            
            <div className="p-4 border-t border-[var(--border-color)]">
              <div className="flex gap-2 mb-2">
                {chatSettings.emojis.map((emoji, idx) => (
                  <button key={idx} onClick={() => setInput(input + emoji)} className="text-xl hover:scale-125 transition-transform">
                    {emoji}
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  className="flex-1 bg-[var(--bg-dark)] border border-[var(--border-color)] rounded-lg px-3 py-2"
                  placeholder="اكتب رسالتك..."
                />
                <button onClick={handleSend} className="bg-[var(--primary-color)] hover:bg-purple-600 text-white px-4 rounded-lg">
                  <div className="icon-send text-xl"></div>
                </button>
              </div>
            </div>
          </div>
        )}
      </>
    );
  } catch (error) {
    console.error('SupportChat component error:', error);
    return null;
  }
}