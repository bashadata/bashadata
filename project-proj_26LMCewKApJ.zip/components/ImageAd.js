function ImageAd({ settings, isAdmin, onEditClick }) {
  try {
    if (!settings.imageAd) return null;
    
    return (
      <div className="my-6 relative" data-name="image-ad" data-file="components/ImageAd.js">
        {isAdmin && (
          <button onClick={onEditClick} className="absolute top-2 left-2 z-10 bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm">
            حذف
          </button>
        )}
        <img src={settings.imageAd} alt="إعلان" className="w-full h-48 object-cover rounded-lg" />
      </div>
    );
  } catch (error) {
    console.error('ImageAd component error:', error);
    return null;
  }
}