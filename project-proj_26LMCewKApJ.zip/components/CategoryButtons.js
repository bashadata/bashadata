function CategoryButtons({ onAddItem, onCategoryClick }) {
  try {
    const [showForm, setShowForm] = React.useState(false);
    const [category, setCategory] = React.useState('');
    const [formData, setFormData] = React.useState({
      name: '',
      size: '',
      image: '',
      notes: '',
      season: '',
      episodes: ''
    });

    const categories = [
      { id: 'arabic-series', label: 'مسلسل عربي', icon: 'tv' },
      { id: 'foreign-series', label: 'مسلسل أجنبي', icon: 'monitor' },
      { id: 'arabic-movie', label: 'فيلم عربي', icon: 'film' },
      { id: 'foreign-movie', label: 'فيلم أجنبي', icon: 'clapperboard' },
      { id: 'cartoon', label: 'كرتون', icon: 'smile' },
      { id: 'anime', label: 'أنمي', icon: 'sparkles' },
      { id: 'game', label: 'لعبة', icon: 'gamepad-2' },
      { id: 'program', label: 'برنامج', icon: 'package' }
    ];

    const handleSubmit = (e) => {
      e.preventDefault();
      onAddItem({ ...formData, category });
      setShowForm(false);
      setFormData({ name: '', size: '', image: '', notes: '', season: '', episodes: '' });
    };

    return (
      <div className="my-8" data-name="category-buttons" data-file="components/CategoryButtons.js">
        <h2 className="text-2xl font-bold mb-6 text-center">إضافة عنصر جديد</h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {categories.map(cat => (
            <div key={cat.id} className="card hover:border-[var(--primary-color)] transition-all text-center p-6">
              <div className={`icon-${cat.icon} text-3xl mb-2 text-[var(--primary-color)]`}></div>
              <span className="font-semibold block mb-2">{cat.label}</span>
              <div className="flex gap-2">
                <button onClick={() => { setCategory(cat.id); setShowForm(true); }} className="btn-primary flex-1 text-sm py-1">إضافة</button>
                <button onClick={() => onCategoryClick(cat.id)} className="btn-secondary flex-1 text-sm py-1">عرض</button>
              </div>
            </div>
          ))}
        </div>

        {showForm && (
          <div className="card max-w-2xl mx-auto">
            <h3 className="text-xl font-bold mb-4">إضافة {categories.find(c => c.id === category)?.label}</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="text"
                placeholder="الاسم"
                className="input-field"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
                required
              />
              <input
                type="text"
                placeholder="الحجم (GB)"
                className="input-field"
                value={formData.size}
                onChange={e => setFormData({...formData, size: e.target.value})}
                required
              />
              <div>
                <label className="block mb-2">إضافة صورة</label>
                <input
                  type="file"
                  accept="image/*"
                  className="input-field"
                  onChange={e => {
                    const file = e.target.files[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = () => setFormData({...formData, image: reader.result});
                      reader.readAsDataURL(file);
                    }
                  }}
                />
              </div>
              <input
                type="text"
                placeholder="الموسم"
                className="input-field"
                value={formData.season}
                onChange={e => setFormData({...formData, season: e.target.value})}
              />
              <input
                type="text"
                placeholder="عدد الحلقات"
                className="input-field"
                value={formData.episodes}
                onChange={e => setFormData({...formData, episodes: e.target.value})}
              />
              <textarea
                placeholder="ملاحظات"
                className="input-field"
                rows="3"
                value={formData.notes}
                onChange={e => setFormData({...formData, notes: e.target.value})}
              />
              <div className="flex gap-4">
                <button type="submit" className="btn-primary flex-1">إضافة</button>
                <button type="button" onClick={() => setShowForm(false)} className="btn-secondary flex-1">إلغاء</button>
              </div>
            </form>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('CategoryButtons component error:', error);
    return null;
  }
}
