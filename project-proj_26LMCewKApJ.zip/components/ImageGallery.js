function ImageGallery({ images, onAddImage, onDeleteImage, isAdmin }) {
  try {
    const [showForm, setShowForm] = React.useState(false);
    const [currentIndex, setCurrentIndex] = React.useState(0);
    const [formData, setFormData] = React.useState({ name: '', image: '' });

    const handleSubmit = (e) => {
      e.preventDefault();
      onAddImage(formData);
      setShowForm(false);
      setFormData({ name: '', image: '' });
    };

    const handleShare = (platform, image) => {
      const text = `${image.name} - ماذا تنتظر؟ ميزات جديدة قادمة قريباً!`;
      const url = encodeURIComponent(image.image);
      if (platform === 'whatsapp') {
        window.open(`https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`);
      } else if (platform === 'facebook') {
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`);
      }
    };

    return (
      <div data-name="image-gallery" data-file="components/ImageGallery.js">
        <h2 className="text-3xl font-bold mb-6 text-center">معرض الصور</h2>
        
        {isAdmin && (
          <button onClick={() => setShowForm(!showForm)} className="btn-primary mb-6">
            إضافة صورة
          </button>
        )}

        {showForm && isAdmin && (
          <div className="card max-w-2xl mx-auto mb-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <input type="text" placeholder="اسم الصورة" className="input-field" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} required />
              <input type="file" accept="image/*" className="input-field" onChange={e => {
                const file = e.target.files[0];
                if (file) {
                  const reader = new FileReader();
                  reader.onload = () => setFormData({...formData, image: reader.result});
                  reader.readAsDataURL(file);
                }
              }} required />
              <button type="submit" className="btn-primary w-full">إضافة</button>
            </form>
          </div>
        )}

        {images.length > 0 && (
          <div className="card max-w-4xl mx-auto">
            <div className="relative">
              <img src={images[currentIndex]?.image} alt={images[currentIndex]?.name} className="w-full h-96 object-contain rounded-lg" />
              <button onClick={() => setCurrentIndex(Math.max(0, currentIndex - 1))} className="absolute left-4 top-1/2 -translate-y-1/2 bg-white text-black p-3 rounded-full" disabled={currentIndex === 0}>
                <div className="icon-chevron-left text-xl"></div>
              </button>
              <button onClick={() => setCurrentIndex(Math.min(images.length - 1, currentIndex + 1))} className="absolute right-4 top-1/2 -translate-y-1/2 bg-white text-black p-3 rounded-full" disabled={currentIndex === images.length - 1}>
                <div className="icon-chevron-right text-xl"></div>
              </button>
            </div>
            <div className="mt-4 text-center">
              <h3 className="text-xl font-bold mb-2">{images[currentIndex]?.name}</h3>
              <p className="text-gray-400 mb-4">ماذا تنتظر؟ ميزات جديدة قادمة قريباً! 🎁</p>
              {isAdmin && (
                <div className="flex gap-2 justify-center">
                  <button onClick={() => handleShare('whatsapp', images[currentIndex])} className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2">
                    <div className="icon-message-circle"></div>
                    مشاركة واتساب
                  </button>
                  <button onClick={() => handleShare('facebook', images[currentIndex])} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2">
                    <div className="icon-facebook"></div>
                    مشاركة فيسبوك
                  </button>
                  <button onClick={() => onDeleteImage(images[currentIndex].id)} className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg">حذف</button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('ImageGallery component error:', error);
    return null;
  }
}