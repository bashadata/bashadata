function ContactSection({ settings, isAdmin, onEditClick }) {
  try {
    const socialButtons = [
      { name: 'واتساب', icon: 'message-circle', color: 'bg-green-600', link: `https://wa.me/${settings.phone}` },
      { name: 'تيليجرام', icon: 'send', color: 'bg-blue-500', link: `https://t.me/${settings.phone}` },
      { name: 'فيسبوك', icon: 'facebook', color: 'bg-blue-600', link: settings.facebookLink || '#' }
    ];

    return (
      <div className="card my-12" data-name="contact-section" data-file="components/ContactSection.js">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">تواصل معنا</h2>
          {isAdmin && (
            <button onClick={onEditClick} className="btn-primary text-sm">
              <div className="icon-edit text-lg"></div>
            </button>
          )}
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="text-center">
            {settings.ownerImage ? (
              <img src={settings.ownerImage} alt="صاحب الموقع" className="w-48 h-48 mx-auto mb-4 rounded-lg object-cover" />
            ) : (
              <div className="w-32 h-32 bg-[var(--secondary-color)] rounded-full mx-auto mb-4 flex items-center justify-center">
                <div className="icon-user text-5xl text-[var(--primary-color)]"></div>
              </div>
            )}
            <h3 className="text-xl font-bold mb-2">صاحب الموقع</h3>
            <p className="text-gray-400 mb-4 text-2xl font-bold">{settings.phone || '01271994344'}</p>
            
            <button className="btn-secondary flex items-center gap-2 mx-auto">
              <div className="icon-map-pin text-xl"></div>
              <span>العنوان</span>
            </button>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">تواصل معنا</h3>
            <div className="grid grid-cols-2 gap-4 mb-4">
              {socialButtons.map(btn => (
                <a
                  key={btn.name}
                  href={settings.whatsappLink && btn.name === 'واتساب' ? settings.whatsappLink : settings.telegramLink && btn.name === 'تيليجرام' ? settings.telegramLink : settings.facebookLink && btn.name === 'فيسبوك' ? settings.facebookLink : btn.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`${btn.color} hover:opacity-90 text-white py-3 px-4 rounded-lg transition-all flex items-center justify-center gap-2`}
                >
                  <div className={`icon-${btn.icon} text-xl`}></div>
                  <span>{btn.name}</span>
                </a>
              ))}
            </div>
            
            {settings.socialFooterImage && (
              <img src={settings.socialFooterImage} alt="Social Footer" className="w-full rounded-lg mb-4" />
            )}
            
            {settings.orangeCashImage && (
              <div className="bg-[var(--bg-dark)] p-4 rounded-lg text-center">
                <img src={settings.orangeCashImage} alt="Orange Cash" className="w-32 h-32 mx-auto mb-2 rounded-lg object-cover" />
                <h4 className="font-bold text-lg">{settings.orangeCashName || 'Orange Cash'}</h4>
                <p className="text-xl font-bold text-orange-500">{settings.orangeCashNumber}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ContactSection component error:', error);
    return null;
  }
}