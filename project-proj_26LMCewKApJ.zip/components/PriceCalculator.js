function PriceCalculator({ settings, isAdmin, onEditClick }) {
  try {
    const [hdSize, setHdSize] = React.useState('');
    const [dataSize, setDataSize] = React.useState('');
    const [total, setTotal] = React.useState(0);
    
    const calculatorTitle = settings.calculatorTitle || 'حاسبة الأسعار 💰';
    
    const hdPrices = {
      '500': 180, '1000': 200, '2000': 260, '3000': 300, '4000': 350, '5000': 390
    };
    
    const calculateTotal = () => {
      const hdPrice = parseInt(hdSize) || 0;
      const dataPrice = parseInt(dataSize) || 0;
      setTotal(hdPrice + dataPrice);
    };
    
    const prices = settings.prices || [
      { size: '500GB', price: '180', type: 'ألعاب' },
      { size: '1TB', price: '200', type: 'ألعاب' },
      { size: '2TB', price: '260', type: 'ألعاب' },
      { size: '3TB', price: '300', type: 'ألعاب' },
      { size: '4TB', price: '350', type: 'ألعاب' },
      { size: '5TB', price: '390', type: 'ألعاب' }
    ];

    const externalPrices = settings.externalPrices || [
      { size: '750GB', price: '950', note: 'للاب توب + بيانات' },
      { size: '640GB', price: '750', note: 'للاب توب + بيانات' }
    ];
    
    const hardDriveImages = settings.hardDriveImages || [];

    return (
      <div className="card my-12" data-name="price-calculator" data-file="components/PriceCalculator.js">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="icon-calculator text-3xl text-[var(--primary-color)]"></div>
            <h2 className="text-2xl font-bold">{calculatorTitle}</h2>
          </div>
          {isAdmin && (
            <button onClick={onEditClick} className="btn-primary text-sm">
              <div className="icon-edit text-lg"></div>
            </button>
          )}
        </div>
        
        {hardDriveImages && hardDriveImages.length > 0 && (
          <div className="mb-8">
            <h3 className="text-xl font-semibold mb-4">صور الهاردات</h3>
            <div className="grid grid-cols-3 gap-4">
              {hardDriveImages.map((hd, idx) => (
                <div key={idx} className="text-center">
                  <img src={hd.image} alt={hd.name} className="w-full h-48 object-cover rounded-lg mb-2" />
                  <p className="font-bold">{hd.name}</p>
                  <p className="text-sm text-gray-400">{hd.size}</p>
                </div>
              ))}
            </div>
          </div>
        )}
        
        <h3 className="text-xl font-semibold mb-4 text-[var(--accent-color)]">أسعار PASHA DATA الهاردات</h3>
        
        <div className="grid md:grid-cols-3 gap-4 mb-6">
          {prices.map((item, idx) => (
            <div key={idx} className="bg-[var(--bg-dark)] p-4 rounded-lg border border-[var(--primary-color)]">
              <div className="text-lg font-bold text-[var(--primary-color)]">{item.size}</div>
              <div className="text-xl font-bold my-2">{item.price} جنيه</div>
              <div className="text-sm text-gray-400">({item.type})</div>
            </div>
          ))}
        </div>

        <h3 className="text-xl font-semibold mb-4 text-[var(--accent-color)]">أسعار الهاردات الخارجية</h3>
        <div className="space-y-3 mb-6">
          {externalPrices.map((item, idx) => (
            <div key={idx} className="bg-[var(--bg-dark)] p-4 rounded-lg flex justify-between items-center">
              <span className="font-bold">{item.size} {item.note}</span>
              <span className="text-xl font-bold text-[var(--accent-color)]">{item.price} جنيه</span>
            </div>
          ))}
        </div>

        <div className="bg-[var(--bg-dark)] p-6 rounded-lg mb-6">
          <h3 className="text-xl font-semibold mb-4">احسب السعر</h3>
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <label className="block mb-2">سعر الهارد</label>
              <input type="number" className="input-field" placeholder="أدخل السعر" value={hdSize} onChange={e => setHdSize(e.target.value)} />
            </div>
            <div>
              <label className="block mb-2">سعر البيانات</label>
              <input type="number" className="input-field" placeholder="أدخل السعر" value={dataSize} onChange={e => setDataSize(e.target.value)} />
            </div>
            <div className="flex items-end">
              <button onClick={calculateTotal} className="btn-primary w-full">احسب</button>
            </div>
          </div>
          {total > 0 && (
            <div className="mt-4 text-center">
              <p className="text-2xl font-bold text-[var(--accent-color)]">الإجمالي: {total} جنيه</p>
            </div>
          )}
        </div>

        <div className="text-center bg-gradient-to-r from-purple-600 to-pink-600 p-6 rounded-lg">
          <p className="text-xl font-bold mb-2">🎁 {settings.promoText || 'ماذا تنتظر؟ عروض جديدة قادمة قريباً!'} 🎁</p>
          <p className="text-sm">{settings.supportText || 'الدعم الفني متاح، وإمكانية تخصيص مظهر الهارد'}</p>
        </div>
      </div>
    );
  } catch (error) {
    console.error('PriceCalculator component error:', error);
    return null;
  }
}