function Banner({ text, settings }) {
  try {
    const fontSize = settings?.bannerTextSize || '20';
    const fontWeight = settings?.bannerFontWeight || 'bold';
    const fontStyle = settings?.bannerFontStyle || 'normal';
    const textColor = settings?.bannerTextColor || '#ffffff';
    const emojis = settings?.bannerEmojis || '🎉';
    
    const spanStyle = {
      fontSize: `${fontSize}px`,
      fontWeight: fontWeight,
      fontStyle: fontStyle,
      color: textColor
    };
    
    return (
      <div className="my-6 overflow-hidden bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg" data-name="banner" data-file="components/Banner.js">
        <div className="animate-marquee whitespace-nowrap py-4">
          <span style={spanStyle} className="mx-8">
            {emojis} {text} {emojis}
          </span>
          <span style={spanStyle} className="mx-8">
            {emojis} {text} {emojis}
          </span>
          <span style={spanStyle} className="mx-8">
            {emojis} {text} {emojis}
          </span>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Banner component error:', error);
    return null;
  }
}
