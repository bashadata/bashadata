function Header({ settings, onViewChange, currentUser }) {
  try {
    return (
      <header className="bg-[var(--bg-card)] border-b border-[var(--border-color)] sticky top-0 z-50" data-name="header" data-file="components/Header.js">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {settings.logo ? (
                <img src={settings.logo} alt="Pasha Data" className="h-12 w-12 rounded-lg" />
              ) : (
                <div className="h-12 w-12 bg-[var(--primary-color)] rounded-lg flex items-center justify-center">
                  <div className="icon-database text-2xl text-white"></div>
                </div>
              )}
              <div>
                <h1 className="text-2xl font-bold text-[var(--primary-color)]">Pasha Data</h1>
                <p className="text-sm text-gray-400">إدارة البيانات والمحتوى</p>
              </div>
            </div>
            
            <nav className="flex gap-4 items-center">
              <a href="home.html" className="btn-secondary text-sm">
                الرئيسية
              </a>
              <button onClick={() => onViewChange('images')} className="btn-secondary text-sm">
                عرض الصور
              </button>
              {currentUser && currentUser.isAdmin && (
                <a href="control-panel.html" className="btn-primary text-sm">
                  لوحة التحكم
                </a>
              )}
              <a href="account.html" className="btn-secondary text-sm flex items-center gap-2">
                {currentUser && currentUser.photo ? (
                  <img src={currentUser.photo} alt={currentUser.name} className="w-6 h-6 rounded-full object-cover" />
                ) : (
                  <div className="icon-user text-lg"></div>
                )}
                <span>الحساب</span>
              </a>
              {currentUser && (
                <button onClick={() => {
                  localStorage.removeItem('rememberMe');
                  authLogout();
                }} className="text-sm text-gray-400 hover:text-white">
                  تسجيل الخروج
                </button>
              )}
            </nav>
          </div>
          
          <div className="mt-4 text-center text-sm text-gray-300 leading-relaxed">
            {settings.headerText || 'هذا الموقع مخصص لصفحة Pasha Data لنقل البيانات من (مسلسلات عربية، مسلسلات أجنبية، أفلام عربية، أفلام أجنبية، كرتون، أنمي، ألعاب، وبرامج) بأسعار تنافسية للغاية'}
          </div>
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}